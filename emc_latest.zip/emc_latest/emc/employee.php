<?php include 'header.php';?>
    <section class="inner-page-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2>Employee</h2>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumbs">
						<li><a href="index.php">Home</a></li>
						<li>Employee</li>
					</ul>
                </div>
            </div>
        </div>
    </section>
		<section class="single-services-page">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>Employee</h2>
					</div>
				</div>
			</div>
		</section>
	<?php include 'footer.php';?> 