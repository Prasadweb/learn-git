 <footer>
        <div class="footer1">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <h5>Bhubaneswar</h5>
                        <p>Office No. - 119, 120 & 121, 1st Floor, DLF Cyber City, 
                            Chandaka Industrial Area, Patia, BBSR–751024</p>
                            <p>Tel. no. 0674 – 2973849</p>
                            <p>Email: ecometrix@outlook.com</p>

                    </div>
                    <div class="col-md-3">
                        <h5>Bangalore</h5>
                        <p>204, Malnade Arcade, Vignan Nagar.
                            Kaggadasapura Main Road, 
                            Bangalore – 560075
                        </p>
                        <p>Tel. no. +91 80-40936357</p>
                        <ul class="icon">
                            <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                        </ul>
                        
                    </div>
                    <div class="col-md-3">
                        <div class="f-box">
                            <h5>Links</h5>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="careers.php">Careers</a></li>
                                <li><a href="services.php"> What We Do</a></li>
								<li> <a href="https://ecometrixconsultants.greythr.com/uas/portal/auth/login?login_challenge=5f459dc19afe4d0985cb60882ee84daf">Employee</a></li>
                                <li> <a href="contact.php">Contact</a></li>
                            </ul>
                        </div>
                        
                        
                    </div>
                    <div class="col-md-3">
                        <h5>Newsletter</h5>
                        <p>Subscribe our newsletter to get our latest update & news</p>
                        <div class=" button2">
                            <input type="text" id="email" placeholder="Email address">
                            <button><i class="fa-regular fa-envelope"></i></button>
                        </div>
                    </div>
                </div>
            
            </div>
        </div>
        <div class="footer2">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <p>Copyright © 2022 All Rights Reserved.</p>
                    </div>
                    <div class="col-md-6">
                        <div class="term">
                            <p><a href="terms-condition.php">Terms & Condition  </a>    |  <a href="privacy.php">  Privacy  </a>      |   <a href="contact.php">   Support </a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="js/jquery.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/nav-menu.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>