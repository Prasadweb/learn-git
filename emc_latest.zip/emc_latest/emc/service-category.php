
<div class="single-services-page-right">
    <div class="search">
        <h3>Search</h3>
        <div class="icon-search">
            <input type="text" placeholder="Search.."><i class="fa-sharp fa-solid fa-magnifying-glass"></i>
        </div>
    </div>

    <div class="service-category">
        <h3>Services Category</h3>
        <div class="window">
            <ul>
                <li><a href="urban-planning.php">Urban Planning<span>→</span></a></li>
                <li><a href="water-supply.php">Water Supply<span>→</span></a></li>
                <li><a href="gis-remote-sensing.php">GIS & Remote Sensing<span>→</span></a></li>
                <li><a href="it-solutions.php">IT Solutions<span>→</span></a></li>
                <li><a href="sewerage.php">Sewerage<span>→</span></a></li>
                <li><a href="storm-Water-drainage.php">Storm Water Drainage<span>→</span></a></li>
                <li><a href="utility-asset-management.php">Utility Asset Management<span>→</span></a></li>
                <li><a href="water-supply.php">Institutional Capacity Building<span>→</span></a></li>
            </ul>
        </div>
    </div>
    <div class="question">
            <h3>Have Your Question</h3>
            <div class="fg-1">	
                <input type="text" id="name" placeholder="Name"><i class="fa-solid fa-user"></i>
            </div>
            <div class="fg-1">		
                <input type="text" id="message" placeholder="Your Message"><i class="fa-regular fa-envelope"></i>
            </div>
            
    
            
                <button>Submit Now <i class="fa-regular fa-plus"></i></button>
                
            
    </div>
    <div class="bg">
        <h4>Need help?</h4>
        <div class="need-help">
            <p>We will connect you with a team member who can help.Prefer speaking with a human to feeling
                out a form? call carporate office and

            </p>
            <div class="icon-call">
                    <p><i class="fa-solid fa-phone-volume"></i> <a href="tell:91 80-40936357">91 80-40936357</a></p>
            </div>

        </div>
    </div>

</div>
					